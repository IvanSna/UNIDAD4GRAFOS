/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Takitos13
 */
public class Grafo {
    NodoVertice vertice;
    int i=0;
    public Grafo(){
        vertice=null;
    }
    
    public boolean insertarvertice(char dato){
        NodoVertice nuevo=new NodoVertice(dato);
        if(nuevo==null)return false;
        
        if(vertice== null){
            vertice=nuevo;
            i++;
            return true;
        }
        irUltimo();
        vertice.sig=nuevo;
        nuevo.ant=vertice;
        i++;
        return true;
    }
    private void irUltimo(){
        while(vertice.sig!=null){
            vertice=vertice.sig;
        }
    }
    private void irPrimero(){
        while(vertice.ant!=null){
            vertice=vertice.ant;
        }
    }
    private NodoVertice buscarVertice(char dato){
        if(vertice==null) return null;
        irPrimero();
        for(NodoVertice buscar=vertice; buscar!=null; buscar=buscar.sig){
            if(buscar.dato==dato){
                return buscar;
            }
        }
        return null;
    }
    public boolean insertarAristas(char origen, char destino){
        NodoVertice nodoOrigen=buscarVertice(origen);
        NodoVertice nodoDestino= buscarVertice(destino);
        
        if(nodoOrigen==null || nodoDestino==null){
            return false;
        }
        return nodoOrigen.insertarArista(nodoDestino);
    }
    
    public boolean eliminarArista(char origen, char destino){
        NodoVertice nodoOrigen=buscarVertice(origen);
        NodoVertice nodoDestino=buscarVertice(destino);
        if(nodoOrigen==null || nodoDestino==null){
            return false;
        }
        return nodoOrigen.eliminarArista(nodoDestino);
    }
    
    private boolean unSoloVertice(){
        return vertice.ant==null && vertice.sig==null; 
    }
    
    public boolean eliminarVertice(char dato){
        if(vertice==null) return false;
        NodoVertice temp= buscarVertice(dato);
        if(temp==null) return false;
        
        if(temp.arista!=null) return false;
        
        quitaAristasDeOtroVertice(temp);
        if(temp==vertice){
            if(unSoloVertice()) vertice=null;
            else{
                vertice=temp.sig;
                temp.sig.ant=temp.sig=null;       
            }
            return true;
        }
        if(temp.sig==null){
            temp.ant.sig=temp.ant=null;
            return true;
        }
        
        temp.ant.sig=temp.sig;
        temp.sig.ant=temp.ant;
        temp.sig=temp.ant=null;
        i--;
        return true;
    }
    private void quitaAristasDeOtroVertice(NodoVertice NodoEliminar){
        irPrimero();
        for(NodoVertice buscar = vertice; buscar!=null; buscar=buscar.sig){
            buscar.eliminarArista(NodoEliminar);
        }
    }
     public String mostrar(){
        if(vertice==null){
            return "NO HAY NODOS";
        }
        return mostrar(vertice);
    }
    
    private String mostrar(NodoVertice temp){
        if(temp==null){
            return "";
        }
        return temp.dato+ "\n" + mostrar(temp.ant);
    }
    

     public boolean encontrarArista(char orig,char dest){
        NodoVertice origen = buscarVertice(orig);
        if(origen == null){
            return false;
        }
        if(origen.arista == null){
            return false;
        }
        NodoArista temp = origen.arista;
        if(temp.direccion.dato == dest){
            return true;
        }
        return false;
    }
     
    public String matriz(){ 
        if(vertice == null) return null;
          String[][] m = new String [i][i];

            for(int x = 0; x<m.length; x++){
                for(int y = 0; y<m.length; y++){
                m[x][y]=0+"";
                }   
            }
            irPrimero();
            for(int t = 0; t<m.length; t++){
                for(int s = 0; t<m.length; s++){
                    if(vertice.arista == null){
                         t++;
                         s=0;
                         vertice = vertice.sig;
                        }else{
                             m[t][s] ="1";
                            vertice.arista = vertice.arista.abajo; 
                        }    
                    }   
                }     
        return mostrar(m);
    }
    
    public String mostrar(String[][] cad){
        String cad2="";
        for(int x = 0; x<cad.length; x++){
            for(int y = 0; y<cad.length; y++){
                cad2+= cad[x][y];
            }
                cad2+="\n";
        }
        return cad2;
    }
}
